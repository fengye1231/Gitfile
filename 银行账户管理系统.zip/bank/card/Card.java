package bank.card;

/*
 * 储蓄卡接口类
 * 列出储蓄卡的功能，同时规范继承储蓄卡的其他卡类
 */
public interface Card {
	public void cun();

	public void qu();

	public void getyu();
}
