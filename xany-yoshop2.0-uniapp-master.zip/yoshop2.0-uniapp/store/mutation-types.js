export const ACCESS_TOKEN = 'AccessToken'
export const USER_ID = 'userId'
export const PLATFORM = 'platform'
