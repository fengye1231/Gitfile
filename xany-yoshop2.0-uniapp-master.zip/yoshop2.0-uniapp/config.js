module.exports = {
  // 系统名称
  name: "萤火商城2.0",
  // 必填: 后端api地址, 斜杠/结尾, 参照下面格式
  // 例如: https://www.你的域名.com/index.php?s=/api/
  apiUrl: "https://www.你的域名.com/index.php?s=/api/"
}
