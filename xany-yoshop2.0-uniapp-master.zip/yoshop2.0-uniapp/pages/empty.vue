<template>
  
</template>

<script>

  export default {
    data() {
      return {
    
      }
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
     
    },

    methods: {

    }
  }
</script>

<style lang="scss" scoped>
 
</style>
