import PageCategoryStyleEnum from './Style'

export { PageCategoryStyleEnum }
