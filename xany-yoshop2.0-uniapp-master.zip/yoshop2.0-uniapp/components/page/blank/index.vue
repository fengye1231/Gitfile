<template>
  <!-- 辅助空白 -->
  <view class="diy-blank" :style="{ height: `${itemStyle.height}px`, background: itemStyle.background }">
  </view>
</template>

<script>
  export default {

    /**
     * 组件的属性列表
     * 用于组件自定义设置
     */
    props: {
      itemStyle: Object
    },

    /**
     * 组件的方法列表
     * 更新属性和数据的方法与更新页面数据的方法类似
     */
    methods: {

    }

  }
</script>

<style lang="scss" scoped>

</style>
