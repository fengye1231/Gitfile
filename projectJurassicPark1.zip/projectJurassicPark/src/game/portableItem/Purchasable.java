package game.portableItem;

public interface Purchasable {
    int getEcoPoint();
}
