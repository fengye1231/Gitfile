package game.portableItem;

public enum FoodCapability {
    FEEDALLOSAUR, ALLOSAUREAT,
    FEEDBRACHIOSAUR, BRACHIOSAUREAT,
    FEEDSTEGOSAUR, STEGOSAUREAT,
}
