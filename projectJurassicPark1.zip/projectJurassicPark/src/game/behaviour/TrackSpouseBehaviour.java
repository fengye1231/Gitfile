package game.behaviour;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Location;


import game.portableItem.Fruit;
import game.dinosaur.*;

import game.dinosaur.Allosaur
import java.util.ArrayList;
import java.util.List;

//public class TrackSpouseBehaviour implements Behaviour{
public class TrackSpouseBehaviour {

    protected Dinosaur dinosaur;
    protected Dinosaur myswlf;



//    public TrackSpouseBehaviour(Dinosaur myswlf,Dinosaur dinosaur){this.myswlf=myswlf;this.dinosaur=dinosaur};


//    @Override
    public Action getAction(Dinosaur myswlf,Dinosaur dinosaur, GameMap map) {



        // 寻找最近的可以交配的恐龙
        if(!map.contains(dinosaur) || !map.contains(dinosaur))
            return null;

        if ((myswlf instanceof Brachiosaur)&&(dinosaur instanceof Brachiosaur)&&(myswlf.getGender()!=dinosaur.getGender())){
            //找到 未写完

            }


        }







    }

