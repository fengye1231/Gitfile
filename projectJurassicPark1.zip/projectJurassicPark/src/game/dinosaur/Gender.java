package game.dinosaur;

public enum Gender {
    MALE,FEMALE
}
