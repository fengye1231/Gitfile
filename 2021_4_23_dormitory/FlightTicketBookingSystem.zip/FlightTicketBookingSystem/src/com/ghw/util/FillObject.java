package com.ghw.util;

import java.sql.ResultSet;

public interface FillObject {
	public abstract Object fillObject(ResultSet rs);
}
