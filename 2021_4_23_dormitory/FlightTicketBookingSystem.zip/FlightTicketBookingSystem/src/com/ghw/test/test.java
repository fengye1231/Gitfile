package com.ghw.test;
import com.ghw.frame.*;
public class test {
	public static void main(String[] agrs){
		new MainFrame().setVisible(true);
	}
}
