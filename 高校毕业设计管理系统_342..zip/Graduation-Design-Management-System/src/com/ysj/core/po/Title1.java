package com.ysj.core.po;

public class Title1 {
	private String seltitlState;
	
	private String tName;
	
	private Long titlId;
	
	private Long titlId1;

    private String titlName;

    private String tId;

    private String titlSource;

    private String titlType;

    private String titlDescribe;

    private String titlState;

    private String selState;
    
    private String major;
    
    private String sId;
    
    private int tScore;
    
    private String tComments;
    
    private Double replyScore;
    
    private String replyComments;
    
    private String sName;
    
    private int batch;

	public int getBatch() {
		return batch;
	}

	public void setBatch(int batch) {
		this.batch = batch;
	}

	public Long getTitlId1() {
		return titlId1;
	}

	public void setTitlId1(Long titlId1) {
		this.titlId1 = titlId1;
	}

	public String getSeltitlState() {
		return seltitlState;
	}

	public void setSeltitlState(String seltitlState) {
		this.seltitlState = seltitlState;
	}

	public String gettName() {
		return tName;
	}

	public void settName(String tName) {
		this.tName = tName;
	}

	public Long getTitlId() {
		return titlId;
	}

	public void setTitlId(Long titlId) {
		this.titlId = titlId;
	}

	public String getTitlName() {
		return titlName;
	}

	public void setTitlName(String titlName) {
		this.titlName = titlName;
	}

	public String gettId() {
		return tId;
	}

	public void settId(String tId) {
		this.tId = tId;
	}

	public String getTitlSource() {
		return titlSource;
	}

	public void setTitlSource(String titlSource) {
		this.titlSource = titlSource;
	}

	public String getTitlType() {
		return titlType;
	}

	public void setTitlType(String titlType) {
		this.titlType = titlType;
	}

	public String getTitlDescribe() {
		return titlDescribe;
	}

	public void setTitlDescribe(String titlDescribe) {
		this.titlDescribe = titlDescribe;
	}

	public String getTitlState() {
		return titlState;
	}

	public void setTitlState(String titlState) {
		this.titlState = titlState;
	}

	public String getSelState() {
		return selState;
	}

	public void setSelState(String selState) {
		this.selState = selState;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getsId() {
		return sId;
	}

	public void setsId(String sId) {
		this.sId = sId;
	}

	public int gettScore() {
		return tScore;
	}

	public void settScore(int tScore) {
		this.tScore = tScore;
	}

	public String gettComments() {
		return tComments;
	}

	public void settComments(String tComments) {
		this.tComments = tComments;
	}

	public Double getReplyScore() {
		return replyScore;
	}

	public void setReplyScore(Double replyScore) {
		this.replyScore = replyScore;
	}

	public String getReplyComments() {
		return replyComments;
	}

	public void setReplyComments(String replyComments) {
		this.replyComments = replyComments;
	}

	public String getsName() {
		return sName;
	}

	public void setsName(String sName) {
		this.sName = sName;
	}
    
    
}
