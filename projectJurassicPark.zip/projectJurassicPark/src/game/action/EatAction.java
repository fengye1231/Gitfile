package game.action;

public class EatAction {
}
