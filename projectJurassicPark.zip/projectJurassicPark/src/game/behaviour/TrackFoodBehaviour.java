package game.behaviour;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;


public class TrackFoodBehaviour implements Behaviour{

    @Override
    public Action getAction(Actor actor, GameMap map) {
        // track closest food location 寻找最近的可以吃的食物。
    }
}
