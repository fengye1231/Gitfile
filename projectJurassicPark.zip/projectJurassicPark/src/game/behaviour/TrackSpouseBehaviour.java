package game.behaviour;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;

public class TrackSpouseBehaviour implements Behaviour{
    @Override
    public Action getAction(Actor actor, GameMap map) {
        // 寻找最近的可以交配的恐龙
    }
}
